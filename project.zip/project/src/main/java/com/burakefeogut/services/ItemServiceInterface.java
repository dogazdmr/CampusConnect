package com.burakefeogut.services;

import java.util.List;

import com.burakefeogut.models.ItemModel;

public interface ItemServiceInterface {
    
    public void test();

    public List<ItemModel> getItems();
    public ItemModel getById(int itemId);
    public List<ItemModel> searchItems(String searchTerm);
 
    public int addOne(ItemModel newItem);
 
    public boolean deleteOne(int itemId);
 
    public ItemModel updateOne(int idToUpdate, ItemModel updateItem);
 
    public void init();

    public void destroy();
}