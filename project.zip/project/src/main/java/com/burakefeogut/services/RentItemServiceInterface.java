package com.burakefeogut.services;

import java.util.List;

import com.burakefeogut.models.RentItemModel;

public interface RentItemServiceInterface {

    public void test();

    public List<RentItemModel> getRentItems();
    public RentItemModel getById(int id);
    public List<RentItemModel> searchRentItems(String searchTerm);
 
    public int addOne(RentItemModel newRentItem);
 
    public boolean deleteOne(int id);
 
    public RentItemModel updateOne(int idToUpdate, RentItemModel updateRentItem);
 
    public void init();

    public void destroy();
}