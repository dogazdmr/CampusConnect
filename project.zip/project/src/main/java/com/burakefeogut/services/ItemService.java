package com.burakefeogut.services;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.burakefeogut.data.ItemsAccessInterface;
import com.burakefeogut.models.ItemModel;

@Service
public class ItemService implements ItemServiceInterface{

    @Autowired
    ItemsAccessInterface itemsDAO;

    @Override
    public void test() {
        System.out.println("ItemsBusinessService is workin");
    }

    @Override
    public List<ItemModel> getItems() {
        return itemsDAO.getItems();
    }

    @Override
    public ItemModel getById(int itemId) {
        return itemsDAO.getById(itemId);
    }

    @Override
    public List<ItemModel> searchItems(String searchTerm) {
       return itemsDAO.searchItems(searchTerm);
    }

    @Override
    public int addOne(ItemModel newItem) {
       return itemsDAO.addOne(newItem);
    }

    @Override
    public boolean deleteOne(int itemId) {
       return itemsDAO.deleteOne(itemId);
    }

    @Override
    public ItemModel updateOne(int idToUpdate, ItemModel updateItem) {
       return itemsDAO.updateOne(idToUpdate, updateItem);
    }
    
    @Override
    public void init() {
        System.out.println("Init method of the Items Business Service");
    }

    @Override
    public void destroy() {
       System.out.println("Destroy method of the Items Business Service");
    }
}