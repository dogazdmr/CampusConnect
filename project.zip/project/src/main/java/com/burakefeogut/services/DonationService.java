package com.burakefeogut.services;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.burakefeogut.data.DonationsAccessInterface;
import com.burakefeogut.models.DonationModel;

@Service
public class DonationService implements DonationServiceInterface{

    @Autowired
    DonationsAccessInterface donationsDAO;

    @Override
    public void test() {
        System.out.println("OrdersBusinessService is workin");
    }

    @Override
    public List<DonationModel> getDonations() {
        return donationsDAO.getDonations();
    }

    @Override
    public List<DonationModel> getById(int id) {
        return donationsDAO.getById(id);
    }

    @Override
    public List<DonationModel> searchDonations(String searchTerm) {
       return donationsDAO.searchDonations(searchTerm);
    }

    @Override
    public int addOne(DonationModel newDonation) {
       return donationsDAO.addOne(newDonation);
    }

    @Override
    public boolean deleteOne(int id) {
       return donationsDAO.deleteOne(id);
    }

    @Override
    public DonationModel updateOne(int idToUpdate, DonationModel updateOrder) {
       return donationsDAO.updateOne(idToUpdate, updateOrder);
    }
    
    @Override
    public void init() {
        System.out.println("Init method of the Orders Business Service");
    }

    @Override
    public void destroy() {
       System.out.println("Destroy method of the Orders Business Service");
    }

    
}/* package com.burakefeogut.services;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.burakefeogut.data.DonationsAccessInterface;
import com.burakefeogut.models.DonationModel;

@Service
public class DonationService implements DonationServiceInterface{

    @Autowired
    DonationsAccessInterface donationsDAO;

    @Override
    public void test() {
        System.out.println("OrdersBusinessService is workin");
    }

    @Override
    public List<DonationModel> getDonations() {
        return donationsDAO.getDonations();
    }

    @Override
    public DonationModel getById(int id) {
        return donationsDAO.getById(id);
    }

    @Override
    public List<DonationModel> searchDonations(String searchTerm) {
       return donationsDAO.searchDonations(searchTerm);
    }

    @Override
    public int addOne(DonationModel newDonation) {
       return donationsDAO.addOne(newDonation);
    }

    @Override
    public boolean deleteOne(int id) {
       return donationsDAO.deleteOne(id);
    }

    @Override
    public DonationModel updateOne(int idToUpdate, DonationModel updateOrder) {
       return donationsDAO.updateOne(idToUpdate, updateOrder);
    }
    
    @Override
    public void init() {
        System.out.println("Init method of the Orders Business Service");
    }

    @Override
    public void destroy() {
       System.out.println("Destroy method of the Orders Business Service");
    }

    
}
 */