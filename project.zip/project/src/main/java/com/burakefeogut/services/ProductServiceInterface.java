package com.burakefeogut.services;

import com.burakefeogut.models.ProductModel;

import java.util.List;

public interface ProductServiceInterface
{   public void test();

    public List<ProductModel> getProducts();
    public ProductModel getById(int id);
    public List<ProductModel> searchProducts(int searchTerm);

    public int addOne(ProductModel newProduct);

    public boolean deleteOne(int id);

    public ProductModel updateOne(int idToUpdate, ProductModel updateProduct);

    public void init();

    public void destroy();
}
