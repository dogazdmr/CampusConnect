package com.burakefeogut.services;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.burakefeogut.data.RentItemAccessInterface;
import com.burakefeogut.models.RentItemModel;

@Service
public class RentItemService implements RentItemServiceInterface{
    @Autowired
    RentItemAccessInterface rentitemsDAO;

    @Override
    public void test() {
        System.out.println("RentItemsBusinessService is workin");
    }

    @Override
    public List<RentItemModel> getRentItems() {
        return rentitemsDAO.getRentItems();
    }

    @Override
    public RentItemModel getById(int id) {
        return rentitemsDAO.getById(id);
    }

    @Override
    public List<RentItemModel> searchRentItems(String searchTerm) {
       return rentitemsDAO.searchRentItems(searchTerm);
    }

    @Override
    public int addOne(RentItemModel newRentItem) {
       return rentitemsDAO.addOne(newRentItem);
    }

    @Override
    public boolean deleteOne(int id) {
       return rentitemsDAO.deleteOne(id);
    }

    @Override
    public RentItemModel updateOne(int idToUpdate, RentItemModel updateRentItem) {
       return rentitemsDAO.updateOne(idToUpdate, updateRentItem);
    }
    
    @Override
    public void init() {
        System.out.println("Init method of the Rent Items Business Service");
    }

    @Override
    public void destroy() {
       System.out.println("Destroy method of the Rent Items Business Service");
    }
}