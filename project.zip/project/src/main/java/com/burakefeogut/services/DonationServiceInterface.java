package com.burakefeogut.services;

import java.util.List;

import com.burakefeogut.models.DonationModel;

public interface DonationServiceInterface {
    public void test();

    public List<DonationModel> getDonations();
    public List<DonationModel> getById(int id);
    public List<DonationModel> searchDonations(String searchTerm);
 
    public int addOne(DonationModel newDonation);
 
    public boolean deleteOne(int id);
 
    public DonationModel updateOne(int idToUpdate, DonationModel updateDonation);
 
    public void init();

    public void destroy();
}/* package com.burakefeogut.services;

import java.util.List;

import com.burakefeogut.models.DonationModel;

public interface DonationServiceInterface {
    public void test();

    public List<DonationModel> getDonations();
    public DonationModel getById(int id);
    public List<DonationModel> searchDonations(String searchTerm);
 
    public int addOne(DonationModel newDonation);
 
    public boolean deleteOne(int id);
 
    public DonationModel updateOne(int idToUpdate, DonationModel updateDonation);
 
    public void init();

    public void destroy();
}
 
 */