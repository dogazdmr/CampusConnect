package com.burakefeogut.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.burakefeogut.data.OrdersDataAccessInterface;
import com.burakefeogut.models.OrderModel;

@Service
@Primary

public class OrdersBusinessService implements OrdersBusinessServiceInterface{

    @Autowired
    @Qualifier("ordersDataService")
    OrdersDataAccessInterface ordersDAO;

    @Override
    public void test() {
        System.out.println("OrdersBusinessService is workin");
    }

    @Override
    public List<OrderModel> getOrders() {
        return ordersDAO.getOrders();
    }

    @Override
    public OrderModel getById(long id) {
        return ordersDAO.getById(id);
    }

    @Override
    public List<OrderModel> searchOrders(String searchTerm) {
       return ordersDAO.searchOrders(searchTerm);
    }

    @Override
    public long addOne(OrderModel newOrder) {
       return ordersDAO.addOne(newOrder);
    }

    @Override
    public boolean deleteOne(long id) {
       return ordersDAO.deleteOne(id);
    }

    @Override
    public OrderModel updateOne(long idToUpdate, OrderModel updateOrder) {
       return ordersDAO.updateOne(idToUpdate, updateOrder);
    }
    
    @Override
    public void init() {
        System.out.println("Init method of the Orders Business Service");
    }

    @Override
    public void destroy() {
       System.out.println("Destroy method of the Orders Business Service");
    }

    
}