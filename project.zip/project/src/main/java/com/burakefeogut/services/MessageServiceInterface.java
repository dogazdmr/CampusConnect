package com.burakefeogut.services;

import java.util.List;

import com.burakefeogut.models.MessageModel;

public interface MessageServiceInterface {
    public void test();

    public List<MessageModel> getMessages();
    public MessageModel getByUsers(String from, String to);
    public List<MessageModel> searchMessages(String searchTerm);
 
    public int addOne(MessageModel newClub);
 
    public boolean deleteOne(int id);
 
    public MessageModel updateOne(int idToUpdate, MessageModel updateClub);
 
    public void init();

    public void destroy();
}
