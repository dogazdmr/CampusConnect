package com.burakefeogut.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;
import java.util.Map;

import com.burakefeogut.data.MessagesAccesInterface;
import com.burakefeogut.models.MessageModel;


@Service
public class MessageService implements MessageServiceInterface{

    @Autowired
    MessagesAccesInterface messagesDAO;

    @Override
    public void test() {
        System.out.println("ItemsBusinessService is workin");
    }

    @Override
    public List<MessageModel> getMessages() {
        return messagesDAO.getMessages();
    }

    @Override
    public MessageModel getByUsers(String from, String to) {
        return messagesDAO.getByUsers( from,  to);
    }

    @Override
    public List<MessageModel> searchMessages(String searchTerm) {
       return messagesDAO.searchMessages(searchTerm);
    }

    @Override
    public int addOne(MessageModel newItem) {
       return messagesDAO.addOne(newItem);
    }

    @Override
    public boolean deleteOne(int itemId) {
       return messagesDAO.deleteOne(itemId);
    }

    @Override
    public MessageModel updateOne(int idToUpdate, MessageModel updateItem) {
       return messagesDAO.updateOne(idToUpdate, updateItem);
    }
    
    @Override
    public void init() {
        System.out.println("Init method of the Messages Business Service");
    }

    @Override
    public void destroy() {
       System.out.println("Destroy method of the Messages Business Service");
    }




}