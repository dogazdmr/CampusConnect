package com.burakefeogut.services;

import java.util.List;

import com.burakefeogut.models.OrderModel;

public interface OrdersBusinessServiceInterface {
    public void test();

    public List<OrderModel> getOrders();
    public OrderModel getById(long id);
    public List<OrderModel> searchOrders(String searchTerm);
 
    public long addOne(OrderModel newOrder);
 
    public boolean deleteOne(long id);
 
    public OrderModel updateOne(long idToUpdate, OrderModel updateOrder);
 
    public void init();

    public void destroy();
}
 