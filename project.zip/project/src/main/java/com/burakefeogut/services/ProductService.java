package com.burakefeogut.services;

import com.burakefeogut.data.ProductAccessInterface;
import com.burakefeogut.models.ProductModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ProductService implements ProductServiceInterface{

    @Autowired
    ProductAccessInterface productInterface;
    @Override
    public void test() {
        System.out.println("Product service is working");
    }

    @Override
    public List<ProductModel> getProducts() {
        return productInterface.getProducts();
    }

    @Override
    public ProductModel getById(int id) {
        return productInterface.getById(id);
    }

    @Override
    public List<ProductModel> searchProducts(int searchTerm) {
        return productInterface.searchProducts(searchTerm);
    }

    @Override
    public int addOne(ProductModel newProduct) {
        return productInterface.addOne(newProduct);
    }

    @Override
    public boolean deleteOne(int id) {
        return productInterface.deleteOne(id);
    }

    @Override
    public ProductModel updateOne(int idToUpdate, ProductModel updateProduct) {
        return productInterface.updateOne(idToUpdate,updateProduct);
    }

    @Override
    public void init() {

    }

    @Override
    public void destroy() {

    }
}
