package com.burakefeogut.data;

import java.util.List;

import com.burakefeogut.models.ClubRepresentativeModel;

public interface ClubsRepresentativeAccessInterface {
 
     public ClubRepresentativeModel getByUsername(String username);
     public List<ClubRepresentativeModel> getRepresentatives();
     public int addOne(ClubRepresentativeModel newRepresentative);
}