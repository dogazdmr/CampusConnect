package com.burakefeogut.data;
import java.util.List;
import java.util.Map;
import java.util.HashMap;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.burakefeogut.models.UserMapper;
import com.burakefeogut.models.User;

import javax.sql.DataSource;

@Repository
public class UserAccess implements UserAccessInterface{
    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public User getByUsername(String username) {
        try {
            List<User> results = jdbcTemplate.query(
                "SELECT * FROM user WHERE username = ?", 
                new UserMapper(),
                username
            );
            if (!results.isEmpty()) {
                return results.get(0);
            } else {
                // Log that no user was found with this username
                System.out.println("No user found with username: " + username);
                return null;
            }
        } catch (Exception e) {
            // Log the exception
            System.out.println("Error querying for user: " + e.getMessage());
            return null;
        }
    }
    

    @Override
    public List<User> getUsers(){
    List<User> results = jdbcTemplate.query("SELECT * FROM user ", new UserMapper());
    return results;
    }

    @Override
    public int addOne(User newUser){
        SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
        .withTableName("user")
        .usingGeneratedKeyColumns("id");


    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("id", newUser.getId());
    parameters.put("username", newUser.getUsername());
    parameters.put("password", newUser.getPassword());
    parameters.put("fullname", newUser.getFullname());

    Number result = simpleInsert.executeAndReturnKey(parameters);
    return result.intValue();

    }
}