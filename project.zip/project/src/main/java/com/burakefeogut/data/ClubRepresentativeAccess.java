package com.burakefeogut.data;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import com.burakefeogut.models.ClubRepresentativeMapper;
import com.burakefeogut.models.ClubRepresentativeModel;

@Repository
public class ClubRepresentativeAccess implements ClubsRepresentativeAccessInterface {

    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public ClubRepresentativeModel getByUsername(String username) {
        try {
            List<ClubRepresentativeModel> results = jdbcTemplate.query(
                "SELECT * FROM ClubRepresentatives WHERE username = ?", 
                new ClubRepresentativeMapper(),
                username
            );
            if (!results.isEmpty()) {
                return results.get(0);
            } else {
                // Log that no user was found with this username
                System.out.println("No user found with username: " + username);
                return null;
            }
        } catch (Exception e) {
            // Log the exception
            System.out.println("Error querying for user: " + e.getMessage());
            return null;
        }
    }
    

    @Override
    public List<ClubRepresentativeModel> getRepresentatives(){
    List<ClubRepresentativeModel> results = jdbcTemplate.query("SELECT * FROM ClubRepresentatives ", new ClubRepresentativeMapper());
    return results;
    }

    @Override
    public int addOne(ClubRepresentativeModel newRepresentative){
    SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
    .withTableName("ClubRepresentatives")
    .usingGeneratedKeyColumns("club_id");


Map<String, Object> parameters = new HashMap<String, Object>();
parameters.put("club_id", newRepresentative.getClub_id());
parameters.put("user_id", newRepresentative.getUser_id());
parameters.put("username", newRepresentative.getUsername());
parameters.put("password", newRepresentative.getPassword());

Number result = simpleInsert.executeAndReturnKey(parameters);
return result.intValue();

}
   
}