package com.burakefeogut.data;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import com.burakefeogut.models.RentItemModel;
import com.burakefeogut.models.RentItemMapper;

@Repository
public class RentItemDataService implements RentItemAccessInterface {

    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public RentItemModel getById(int id) {
        String sql = "SELECT * FROM rentitems WHERE id = ?";
        List<RentItemModel> results = jdbcTemplate.query(sql, new RentItemMapper(), id);
        if (results.size() > 0) {
            return results.get(0);
        }
        return null;

    }

    @Override
    public List<RentItemModel> getRentItems() {
        String sql = "SELECT * FROM rentitems ";
        return jdbcTemplate.query(sql, new RentItemMapper());

    }

    @Override
    public int addOne(RentItemModel newRentItem) {
        SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
                .withTableName("rentitems")
                .usingGeneratedKeyColumns("id");

       
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("id", newRentItem.getId());
        parameters.put("name", newRentItem.getName());
        parameters.put("price", newRentItem.getPrice());
        parameters.put("description", newRentItem.getDescription());
        parameters.put("sellerId", newRentItem.getSellerId());
        parameters.put("photo", newRentItem.getPhoto());
        parameters.put("conditionOfProduct", newRentItem.getConditionOfProduct());
        parameters.put("isNegotiable", newRentItem.getIsNegotiable());
        parameters.put("rentDay", newRentItem.getRentDay());
        Number result = simpleInsert.executeAndReturnKey(parameters);
        return result.intValue();
    }

    @Override
    public boolean deleteOne(int id) {
        int result = jdbcTemplate.update("DELETE FROM rentitems WHERE id = ?", id);
        return result > 0;
    }

    @Override
    public RentItemModel updateOne(int idToUpdate, RentItemModel updateRentItem) {
        int result = jdbcTemplate.update("UPDATE rentitems SET name = ?, price = ?, description = ?, sellerId = ?, photo = ?, conditionOfProduct = ?, isNegotiable = ?, rentDay = ?, WHERE id = ?", 
                updateRentItem.getName(), updateRentItem.getPrice(), updateRentItem.getDescription(), updateRentItem.getSellerId(),updateRentItem.getPhoto(), updateRentItem.getConditionOfProduct(), updateRentItem.getIsNegotiable(), updateRentItem.getRentDay(), idToUpdate);
        if (result > 0) {
            return updateRentItem;
        }
        return null;
    }

    @Override
    public List<RentItemModel> searchRentItems(String searchTerm) {
        String sql = "SELECT * FROM rentitems WHERE name LIKE ?";
        return jdbcTemplate.query(sql, new RentItemMapper(), "%" + searchTerm + "%");
    }
}