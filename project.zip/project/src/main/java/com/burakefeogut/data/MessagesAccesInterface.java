package com.burakefeogut.data;

import java.util.List;

import com.burakefeogut.models.MessageModel;

public interface MessagesAccesInterface {
    public MessageModel getByUsers(String from, String to);
    public List<MessageModel> getMessages();
    public List<MessageModel> searchMessages(String message_to);
    public int addOne(MessageModel newClub);
    public boolean deleteOne(int clubID);
    public MessageModel updateOne(int idToUpdate, MessageModel updateClub);
}