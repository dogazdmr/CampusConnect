package com.burakefeogut.data;
import java.util.List;

import com.burakefeogut.models.User;


public interface UserAccessInterface {
    public User getByUsername(String username);
     public List<User> getUsers();
     public int addOne(User newUser);
}