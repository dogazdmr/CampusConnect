package com.burakefeogut.data;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import com.burakefeogut.models.ItemModel;
import com.burakefeogut.models.ItemsMapper;


@Repository
public class ItemsDataService implements ItemsAccessInterface{
    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public ItemModel getById(int itemId) {
    List<ItemModel> results = jdbcTemplate.query("SELECT * FROM ITEM WHERE itemId = ?", new ItemsMapper(), itemId);
    if (results.size()>0)
    return results.get(0);
    return null;
    }

    @Override
    public List<ItemModel> getItems() {
    List<ItemModel> results = jdbcTemplate.query("SELECT * FROM ITEM ", new ItemsMapper());
    return results;
    }

    @Override
    public int addOne(ItemModel newItem) {
        SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
                .withTableName("ITEM")
                .usingGeneratedKeyColumns("itemId");

       
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("itemId", newItem.getItemId());
        parameters.put("itemName", newItem.getItemName());
        parameters.put("itemPlace", newItem.getItemPlace());
        parameters.put("itemDescription", newItem.getItemDescription());
        parameters.put("lostOrFound", newItem.getLostOrFound());
        Number result = simpleInsert.executeAndReturnKey(parameters);
        return result.intValue();

    }



    @Override
    public boolean deleteOne(int itemId) {
    int result = jdbcTemplate.update("DELETE FROM ITEM WHERE itemId = ?", itemId);
    if(result>0)
    return true;
    return false;
    }


    @Override
    public ItemModel updateOne(int idToUpdate, ItemModel updateItem) {
    int result = jdbcTemplate.update("UPDATE ITEM SET itemName = ?, itemPlace = ?, itemDescription = ?, lostOrFound = ?, WHERE itemId = ?", updateItem.getItemName(), updateItem.getItemPlace(), updateItem.getItemDescription(), updateItem.getLostOrFound(), idToUpdate);
    if (result>0)
    return updateItem;
    return null;
    }

    @Override
    public List<ItemModel> searchItems(String searchTerm) {
       List<ItemModel> results = jdbcTemplate.query("SELECT * FROM ITEM WHERE itemName LIKE ?",new ItemsMapper(), "%" + searchTerm + "%");
       return results;
    }
}