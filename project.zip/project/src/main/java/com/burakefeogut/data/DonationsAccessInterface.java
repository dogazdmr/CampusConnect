package com.burakefeogut.data;
import java.util.List;
import com.burakefeogut.models.DonationModel;

public interface DonationsAccessInterface {
 
     public List<DonationModel> getById(int id);
     public List<DonationModel> getDonations();
     public List<DonationModel> searchDonations(String clubName);
     public int addOne(DonationModel newDonation);
     public boolean deleteOne(int id);
     public DonationModel updateOne(int idToUpdate, DonationModel updateDonation);


}/* package com.burakefeogut.data;
import java.util.List;
import com.burakefeogut.models.DonationModel;

public interface DonationsAccessInterface {
 
     public DonationModel getById(int id);
     public List<DonationModel> getDonations();
     public List<DonationModel> searchDonations(String clubName);
     public int addOne(DonationModel newDonation);
     public boolean deleteOne(int id);
     public DonationModel updateOne(int idToUpdate, DonationModel updateDonation);


}
 */