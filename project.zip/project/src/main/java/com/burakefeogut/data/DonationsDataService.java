package com.burakefeogut.data;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import com.burakefeogut.models.DonationModel;
import com.burakefeogut.models.DonationsMapper;

@Repository
public class DonationsDataService implements DonationsAccessInterface {

    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;


    @Override
    public List<DonationModel> getById(int clubid) {
        List<DonationModel> results = jdbcTemplate.query("SELECT * FROM donation WHERE clubid = ?",new DonationsMapper(),clubid);
        return results; // This will return the list of donations matching the clubid
    }
    
    
    @Override
    public List<DonationModel> getDonations() {
    List<DonationModel> results = jdbcTemplate.query("SELECT * FROM donation ", new DonationsMapper());
    return results;
    }

@Override
public int addOne(DonationModel newDonation) {
    SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
            .withTableName("donation")
            .usingGeneratedKeyColumns("ID");

    // Create a map of the column names to the values to be inserted
    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("ID", newDonation.getId());
    parameters.put("DESCRIPTION", newDonation.getDescription());
    parameters.put("CLUBNAME", newDonation.getClubName());
    parameters.put("clubid", newDonation.getClubId());
    Number result = simpleInsert.executeAndReturnKey(parameters);
    return result.intValue();

}



    @Override
    public boolean deleteOne(int id) {
    int result = jdbcTemplate.update("DELETE FROM donation WHERE ID = ?", id);
    if(result>0)
    return true;
    return false;
    }

    @Override
    public DonationModel updateOne(int idToUpdate, DonationModel updateDonation) {
    int result = jdbcTemplate.update("UPDATE donation SET CLUBNAME = ?, clubid = ?, DESCRIPTION = ?, WHERE ID = ?", updateDonation.getClubName(),updateDonation.getClubId(), updateDonation.getDescription(),idToUpdate);
    if (result>0)
    return updateDonation;
    return null;
    }

    @Override
    public List<DonationModel> searchDonations(String searchTerm) {
       List<DonationModel> results = jdbcTemplate.query("SELECT * FROM donation WHERE CLUBNAME LIKE ?",new DonationsMapper(), "%" + searchTerm + "%");
       return results;
    }
    
}/* package com.burakefeogut.data;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import com.burakefeogut.models.DonationModel;
import com.burakefeogut.models.DonationsMapper;

@Repository
public class DonationsDataService implements DonationsAccessInterface {

    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;


    @Override
    public DonationModel getById(int id) {
    List<DonationModel> results = jdbcTemplate.query("SELECT * FROM DONATION WHERE ID = ?", new DonationsMapper(),id);
    if (results.size()>0)
    return results.get(0);
    return null;
    }

    @Override
    public List<DonationModel> getDonations() {
    List<DonationModel> results = jdbcTemplate.query("SELECT * FROM DONATION ", new DonationsMapper());
    return results;
    }

@Override
public int addOne(DonationModel newDonation) {
    SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
            .withTableName("DONATION")
            .usingGeneratedKeyColumns("ID");

    // Create a map of the column names to the values to be inserted
    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("ID", newDonation.getId());
    parameters.put("DESCRIPTION", newDonation.getDescription());
    parameters.put("CLUBNAME", newDonation.getClubName());
    Number result = simpleInsert.executeAndReturnKey(parameters);
    return result.intValue();

}



    @Override
    public boolean deleteOne(int id) {
    int result = jdbcTemplate.update("DELETE FROM DONATION WHERE ID = ?", id);
    if(result>0)
    return true;
    return false;
    }

    @Override
    public DonationModel updateOne(int idToUpdate, DonationModel updateDonation) {
    int result = jdbcTemplate.update("UPDATE DONATION SET CLUBNAME = ?, DESCRIPTION = ?, WHERE ID = ?", updateDonation.getClubName(), updateDonation.getDescription(),idToUpdate);
    if (result>0)
    return updateDonation;
    return null;
    }

    @Override
    public List<DonationModel> searchDonations(String searchTerm) {
       List<DonationModel> results = jdbcTemplate.query("SELECT * FROM DONATION WHERE CLUBNAME LIKE ?",new DonationsMapper(), "%" + searchTerm + "%");
       return results;
    }
    
}

 */