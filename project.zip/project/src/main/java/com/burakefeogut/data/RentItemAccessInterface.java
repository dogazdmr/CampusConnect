package com.burakefeogut.data;

import java.util.List;

import com.burakefeogut.models.RentItemModel;

public interface RentItemAccessInterface {

    public RentItemModel getById(int id);
    public List<RentItemModel> getRentItems();
    public List<RentItemModel> searchRentItems(String name);
    public int addOne(RentItemModel newRentItem);
    public boolean deleteOne(int id);
    public RentItemModel updateOne(int idToUpdate, RentItemModel updateRentItem);
    
}