package com.burakefeogut.data;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;


import com.burakefeogut.models.MessageModel;
import com.burakefeogut.models.MessagesMapper;


@Repository
public class MessagesDataService implements MessagesAccesInterface{
    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public MessageModel getByUsers(String from, String to) {
    List<MessageModel> results = jdbcTemplate.query("SELECT * FROM message WHERE message_from = ? AND message_to = ?", new MessagesMapper(), from, to);
    if (results.size()>0)
    return results.get(0);
    return null;
    }

    @Override
    public List<MessageModel> getMessages() {
    List<MessageModel> results = jdbcTemplate.query("SELECT * FROM message ", new MessagesMapper());
    return results;
    }

    @Override
    public int addOne(MessageModel newMessage) {
        SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
                .withTableName("message")
                .usingGeneratedKeyColumns("id");

       
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("id", newMessage.getId());
        parameters.put("message_text", newMessage.getMessage_text());
        parameters.put("created_datetime", newMessage.getCreated_datetime());
        parameters.put("message_from", newMessage.getMessage_from());
        parameters.put("message_to", newMessage.getMessage_to());
        Number result = simpleInsert.executeAndReturnKey(parameters);
        return result.intValue();

    }



    @Override
    public boolean deleteOne(int itemId) {
    int result = jdbcTemplate.update("DELETE FROM message WHERE id = ?", itemId);
    if(result>0)
    return true;
    return false;
    }


    @Override
    public MessageModel updateOne(int idToUpdate, MessageModel updateMessage) {
    int result = jdbcTemplate.update("UPDATE message SET message_text = ?, created_datetime = ?, message_from = ?, message_to = ?, WHERE id = ?", updateMessage.getMessage_text(), updateMessage.getCreated_datetime(), updateMessage.getMessage_from(), updateMessage.getMessage_to(), idToUpdate);
    if (result>0)
    return updateMessage;
    return null;
    }

    @Override
    public List<MessageModel> searchMessages(String searchTerm) {
       List<MessageModel> results = jdbcTemplate.query("SELECT * FROM message WHERE message_to LIKE ?",new MessagesMapper(), "%" + searchTerm + "%");
       return results;
    }
}