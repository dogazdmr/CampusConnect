package com.burakefeogut.data;

import java.util.List;

import java.util.Map;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import com.burakefeogut.models.OrderModel;
import com.burakefeogut.models.OrdersMapper;

@Repository
public class OrdersDataService implements OrdersDataAccessInterface{

    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;


    @Override
    public OrderModel getById(long id) {
    List<OrderModel> results = jdbcTemplate.query("SELECT * FROM Sercap WHERE ID = ?", new OrdersMapper(),id);
    if (results.size()>0)
    return results.get(0);
    return null;
    }

    @Override
    public List<OrderModel> getOrders() {
    List<OrderModel> results = jdbcTemplate.query("SELECT * FROM Sercap ", new OrdersMapper());
    return results;
    }

@Override
public long addOne(OrderModel newOrder) {
    // Create an instance of SimpleJdbcInsert
    SimpleJdbcInsert simpleInsert = new SimpleJdbcInsert(jdbcTemplate)
            .withTableName("Sercap")
            .usingGeneratedKeyColumns("ID");

    // Create a map of the column names to the values to be inserted
    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("ORDER_NUMBER", newOrder.getOrderNo());
    parameters.put("PRODUCT_NAME", newOrder.getProductName());
    parameters.put("PRICE", newOrder.getPrice());
    parameters.put("QTY", newOrder.getQuantity());

    Number result = simpleInsert.executeAndReturnKey(parameters);
    return result.longValue();

}



    @Override
    public boolean deleteOne(long id) {
    int result = jdbcTemplate.update("DELETE FROM Sercap WHERE ID = ?", id);
    if(result>0)
    return true;
    return false;
    }

    @Override
    public OrderModel updateOne(long idToUpdate, OrderModel updateOrder) {
    int result = jdbcTemplate.update("UPDATE Sercap SET ORDER_NUMBER = ?, PRODUCT_NAME = ?, PRICE = ?, QTY = ? WHERE ID = ?", updateOrder.getId(), updateOrder.getProductName(), updateOrder.getPrice(), updateOrder.getQuantity(),idToUpdate);
    if (result>0)
    return updateOrder;
    return null;
    }

    @Override
    public List<OrderModel> searchOrders(String searchTerm) {
       List<OrderModel> results = jdbcTemplate.query("SELECT * FROM Sercap WHERE PRODUCT_NAME LIKE ?",new OrdersMapper(), "%" + searchTerm + "%");
       return results;
    }
    
}
