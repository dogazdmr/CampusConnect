package com.burakefeogut.data;
import java.util.List;
import com.burakefeogut.models.ItemModel;


public interface ItemsAccessInterface {
    public ItemModel getById(int itemId);
    public List<ItemModel> getItems();
    public List<ItemModel> searchItems(String itemName);
    public int addOne(ItemModel newItem);
    public boolean deleteOne(int itemId);
    public ItemModel updateOne(int idToUpdate, ItemModel updateItem);
}