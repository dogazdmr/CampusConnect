package com.burakefeogut.data;

import com.burakefeogut.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;

@Repository
public class ProductDataService implements ProductAccessInterface{
    @Autowired
    private JdbcTemplate jdbcTemplate;


    @Override
    public ProductModel getById(int id) {
        String sql = "SELECT * FROM products  WHERE products.seller_id = ?";
        return jdbcTemplate.queryForObject(sql,new ProductMapper(), id);
    }

    @Override
    public List<ProductModel> getProducts() {
        String sql = "SELECT * FROM products ";
        return jdbcTemplate.query(sql,new ProductMapper());
    }

    @Override
    public List<ProductModel> searchProducts(int id) {
        String sql = "SELECT * FROM products where products.seller_id LIKE ?";
        return jdbcTemplate.query(sql,new ProductMapper(), id);
    }

    @Override
    public int addOne(ProductModel newProduct) {
        String productSql = "INSERT INTO products (name, price, description, seller_id, photo, conditionOfProduct, isNegotiable) VALUES (?, ?, ?, ?, ?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(productSql, new String[]{"id"});
            ps.setString(1, newProduct.getName());
            ps.setDouble(2, newProduct.getPrice());
            ps.setString(3, newProduct.getDescription());
            ps.setInt(4, newProduct.getSellerId());
            ps.setString(5, newProduct.getPhoto());
            ps.setInt(6, newProduct.getConditionOfProduct());
            ps.setBoolean(7, newProduct.isNegotiable());
            return ps;
        }, keyHolder);

        int newProductId = keyHolder.getKey().intValue();
        return newProductId;
    }

    @Override
    public boolean deleteOne(int id) {
        String productSql = "DELETE FROM products WHERE id = ?";
        return jdbcTemplate.update(productSql, id) > 0;
    }

    @Override
    public ProductModel updateOne(int idToUpdate, ProductModel updateProduct) {
        String productSql = "UPDATE products SET name = ?, price = ?, description = ?, seller_id = ?, photo = ?, conditionOfProduct = ? , isNegotiable = ? WHERE id = ?";
        jdbcTemplate.update(productSql,updateProduct.getName(), updateProduct.getPrice(), updateProduct.getDescription(), updateProduct.getSellerId(), updateProduct.getPhoto(), updateProduct.getConditionOfProduct(),updateProduct.isNegotiable(), idToUpdate);

        return getById(idToUpdate);
    }
}
