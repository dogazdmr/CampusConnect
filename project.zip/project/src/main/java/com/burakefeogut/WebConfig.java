package com.burakefeogut;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // Apply CORS settings to more URL patterns as needed
        registry.addMapping("/api/**") // This covers both /api/donations and /api/auth
                .allowedOrigins("http://localhost:5173") // Your frontend's URL
                .allowedMethods("GET", "POST", "PUT", "DELETE") // Include OPTIONS if needed
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}


/* package com.burakefeogut;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/donations/**")
                .allowedOrigins("http://localhost:5173")
                .allowedMethods("GET", "POST", "PUT", "DELETE") // Include DELETE if needed
                .allowedHeaders("*")
                .allowCredentials(true);
    }
} */