package com.burakefeogut.controllers;

import com.burakefeogut.models.ProductModel;
import com.burakefeogut.services.ProductServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/secondhand")
public class SecondHandController {
    ProductServiceInterface service;
    @Autowired
    public SecondHandController(ProductServiceInterface service){
        super();
        this.service = service;
    }

    @GetMapping("/")
    public List<ProductModel> showAllProducts(Model model){
        List<ProductModel> products = service.getProducts();
        return products;
    }

    @GetMapping("/{searchTerm}")
    public List<ProductModel> searchProduct(@PathVariable(name="searchTerm") int searchTerm){
        List<ProductModel> products = service.searchProducts(searchTerm);
        return products;
    }
    @PostMapping("/")   //Used for adding smth to database
    public long addBook(@RequestBody ProductModel model){
        return service.addOne(model);
    }

    @GetMapping("/delete/{id}")
    public boolean deleteOne(@PathVariable(name="id") int abc) {
        return service.deleteOne(abc);
    }

    @PutMapping("/update/{id}")   //Used for adding smth to database
    public ProductModel updateOne(@RequestBody ProductModel model,@PathVariable(name="id") int id){
        return service.updateOne(id, model);}
}
