package com.burakefeogut.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.burakefeogut.models.MessageModel;
import com.burakefeogut.services.MessageService;
import com.burakefeogut.services.MessageServiceInterface;
import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

/* @RestController
@CrossOrigin */
@RestController
@RequestMapping("/api/messages")
public class MessageController {

    MessageServiceInterface service;

    @Autowired
     public MessageController(MessageServiceInterface service){
        super();
        this.service = service;
     }

    @GetMapping("/")
    public List<MessageModel> showAllItems(Model model){
        List<MessageModel> items = service.getMessages();
        return items;
    }

    @GetMapping("/search/{searchTerm}")
    public List<MessageModel> searchItem(@PathVariable(name="searchTerm") String searchTerm){
        List<MessageModel> items = service.searchMessages(searchTerm);
        return items;
    }

    @PostMapping("/")   //Used for adding smth to database
    public long addItem(@RequestBody MessageModel model){
        return service.addOne(model);
    }

    @GetMapping("/{message_from}/{message_to}")
    public MessageModel getByUsers(@PathVariable(name="message_from") String messageFrom, 
                                @PathVariable(name="message_to") String messageTo) {
        return service.getByUsers(messageFrom, messageTo);
    }

    @GetMapping("/delete/{itemId}")
    public boolean deleteOne(@PathVariable(name="itemId") int abc) {
        return service.deleteOne(abc);
    }

    @PutMapping("/update/{itemId}")   //Used for adding smth to database
    public MessageModel updateOne(@RequestBody MessageModel model,@PathVariable(name="itemId") int itemId){
        return service.updateOne(itemId, model);
    }
}