package com.burakefeogut.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.burakefeogut.data.ClubRepresentativeAccess;
import com.burakefeogut.models.ClubRepresentativeModel;

@RestController
@RequestMapping("/api/club/auth")
public class ClubAuthenticationController{

    @Autowired
    ClubRepresentativeAccess clubRepAccess;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        ClubRepresentativeModel rep = clubRepAccess.getByUsername(loginRequest.getUsername());
        if (rep != null && rep.getPassword().equals(loginRequest.getPassword())) {
            ClubLoginResponse response = new ClubLoginResponse("Login successful", rep.getClub_id());
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Credentials");
        }
    }
}