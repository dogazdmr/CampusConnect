package com.burakefeogut.controllers;

public class ClubLoginResponse {
        private String message;
        private int clubId;

        public ClubLoginResponse(String message, int clubId) {
            this.message = message;
            this.clubId = clubId;
        }

        // Getters
        public String getMessage() {
            return message;
        }

        public int getClubId() {
            return clubId;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public void setClubId(int clubId) {
            this.clubId = clubId;
        }

        
    }