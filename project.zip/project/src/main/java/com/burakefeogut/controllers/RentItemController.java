package com.burakefeogut.controllers;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.burakefeogut.models.RentItemModel;
import com.burakefeogut.services.RentItemService;
import com.burakefeogut.services.RentItemServiceInterface;
import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

@RestController
@RequestMapping("/api/rentitems")
public class RentItemController {
    RentItemServiceInterface service;

     @Autowired
     public RentItemController(RentItemServiceInterface service){
        super();
        this.service = service;
     }

    @GetMapping("/")
    public List<RentItemModel> showAllRentItems(Model model){
        List<RentItemModel> rentitems = service.getRentItems();
        return rentitems;
    }

    @GetMapping("/search/{searchTerm}")
    public List<RentItemModel> searchRentItem(@PathVariable(name="searchTerm") String searchTerm){
        List<RentItemModel> rentitems = service.searchRentItems(searchTerm);
        return rentitems;
    }

    @PostMapping("/")  
    public long addRentItem(@RequestBody RentItemModel model){
        return service.addOne(model);
    }

    @GetMapping("/{id}")
    public RentItemModel getById(@PathVariable(name="id") int id) {
        return service.getById(id);
    }

    @GetMapping("/delete/{id}")
    public boolean deleteOne(@PathVariable(name="id") int abc) {
        return service.deleteOne(abc);
    }

    @PutMapping("/update/{id}")   
    public RentItemModel updateOne(@RequestBody RentItemModel model,@PathVariable(name="id") int id){
        return service.updateOne(id, model);
    }
}