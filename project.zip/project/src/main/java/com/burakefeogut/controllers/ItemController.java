package com.burakefeogut.controllers;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.burakefeogut.models.ItemModel;
import com.burakefeogut.services.ItemService;
import com.burakefeogut.services.ItemServiceInterface;
import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

@RestController
@RequestMapping("/api/items")
public class ItemController {
    ItemServiceInterface service;

     @Autowired
     public ItemController(ItemServiceInterface service){
        super();
        this.service = service;
     }

    @GetMapping("/")
    public List<ItemModel> showAllItems(Model model){
        List<ItemModel> items = service.getItems();
        return items;
    }

    @GetMapping("/search/{searchTerm}")
    public List<ItemModel> searchItem(@PathVariable(name="searchTerm") String searchTerm){
        List<ItemModel> items = service.searchItems(searchTerm);
        return items;
    }

    @PostMapping("/")   //Used for adding smth to database
    public long addItem(@RequestBody ItemModel model){
        return service.addOne(model);
    }

    @GetMapping("/{itemId}")
    public ItemModel getById(@PathVariable(name="itemId") int itemId) {
        return service.getById(itemId);
    }

    @GetMapping("/delete/{itemId}")
    public boolean deleteOne(@PathVariable(name="itemId") int abc) {
        return service.deleteOne(abc);
    }

    @PutMapping("/update/{itemId}")   //Used for adding smth to database
    public ItemModel updateOne(@RequestBody ItemModel model,@PathVariable(name="itemId") int itemId){
        return service.updateOne(itemId, model);
    }
}