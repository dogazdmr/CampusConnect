package com.burakefeogut.controllers;

public class UserLoginResponse {
        private String message;
        private int userid;
        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }
        public int getUserid() {
            return userid;
        }
        public void setUserid(int userid) {
            this.userid = userid;
        }
        public UserLoginResponse(String message, int userid) {
            this.message = message;
            this.userid = userid;
        }

       

}