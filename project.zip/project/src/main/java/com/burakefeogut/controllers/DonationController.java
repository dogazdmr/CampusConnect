package com.burakefeogut.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.burakefeogut.models.DonationModel;
import com.burakefeogut.services.DonationService;
import com.burakefeogut.services.DonationServiceInterface;
import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

@RestController
@RequestMapping("/api/donations")
public class DonationController {
    
    DonationServiceInterface service;
     @Autowired
     public DonationController(DonationServiceInterface service){
        super();
        this.service = service;
     }

    @GetMapping("/")
    public List<DonationModel> showAllDonations(Model model){
        List<DonationModel> donations = service.getDonations();
        return donations;
    }

    @GetMapping("/search/{searchTerm}")
    public List<DonationModel> searchDonation(@PathVariable(name="searchTerm") String searchTerm){
        List<DonationModel> donations = service.searchDonations(searchTerm);
        return donations;
    }

    @PostMapping("/")   //Used for adding smth to database
    public long addDonation(@RequestBody DonationModel model){
        return service.addOne(model);
    }

    @GetMapping("/{id}")
    public List<DonationModel> getById(@PathVariable(name="id") int id) {
        return service.getById(id);
    }

    @GetMapping("/delete/{id}")
    public boolean deleteOne(@PathVariable(name="id") int abc) {
        return service.deleteOne(abc);
    }

    @PutMapping("/update/{id}")   //Used for adding smth to database
    public DonationModel updateOne(@RequestBody DonationModel model,@PathVariable(name="id") int id){
        return service.updateOne(id, model);
    }

}/* package com.burakefeogut.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.burakefeogut.models.DonationModel;
import com.burakefeogut.services.DonationService;
import com.burakefeogut.services.DonationServiceInterface;
import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

@RestController
@RequestMapping("/api/donations")
public class DonationController {
    
    DonationServiceInterface service;
     @Autowired
     public DonationController(DonationServiceInterface service){
        super();
        this.service = service;
     }

    @GetMapping("/")
    public List<DonationModel> showAllDonations(Model model){
        List<DonationModel> donations = service.getDonations();
        return donations;
    }

    @GetMapping("/search/{searchTerm}")
    public List<DonationModel> searchDonation(@PathVariable(name="searchTerm") String searchTerm){
        List<DonationModel> donations = service.searchDonations(searchTerm);
        return donations;
    }

    @PostMapping("/")   //Used for adding smth to database
    public long addDonation(@RequestBody DonationModel model){
        return service.addOne(model);
    }

    @GetMapping("/{id}")
    public DonationModel getById(@PathVariable(name="id") int id) {
        return service.getById(id);
    }

    @GetMapping("/delete/{id}")
    public boolean deleteOne(@PathVariable(name="id") int abc) {
        return service.deleteOne(abc);
    }

    @PutMapping("/update/{id}")   //Used for adding smth to database
    public DonationModel updateOne(@RequestBody DonationModel model,@PathVariable(name="id") int id){
        return service.updateOne(id, model);
    }

}
 */