package com.burakefeogut.models;

public class ItemModel {
    int itemId;
    String itemName;
    String itemPlace;
    String itemDescription;
    boolean lostOrFound;
    
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemPlace() {
        return itemPlace;
    }

    public void setItemPlace(String itemPlace) {
        this.itemPlace = itemPlace;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public boolean getLostOrFound() {
        return lostOrFound;
    }

    public void setLostOrFound(boolean lostOrFound) {
        this.lostOrFound = lostOrFound;
    }
    
    public ItemModel(int itemId, String itemName, String itemPlace, String itemDescription, boolean lostOrFound) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemPlace = itemPlace;
        this.itemDescription = itemDescription;
        this.lostOrFound = lostOrFound;
    }

}
