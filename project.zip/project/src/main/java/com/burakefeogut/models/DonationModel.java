package com.burakefeogut.models;

public class DonationModel {
    int donationId;
    int clubid;
    String description;
    String clubName;
    public int getId() {
        return donationId;
    }
    public void setId(int id) {
        this.donationId = id;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getClubName() {
        return clubName;
    }
    public void setClubName(String clubName) {
        this.clubName = clubName;
    }
    public int getClubId() {
        return clubid;
    }
    public void setClubId(int clubid) {
        this.clubid = clubid;
    }
    public DonationModel(int id, int clubid, String description, String clubName) {
        this.donationId = id;
        this.description = description;
        this.clubName = clubName;
        this.clubid = clubid;
    }
    
    
}/* package com.burakefeogut.models;

public class DonationModel {
    int id;
    String description;
    String clubName;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getClubName() {
        return clubName;
    }
    public void setClubName(String clubName) {
        this.clubName = clubName;
    }
    public DonationModel(int id, String description, String clubName) {
        this.id = id;
        this.description = description;
        this.clubName = clubName;
    }
    
    
}

 */