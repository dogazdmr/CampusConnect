
package com.burakefeogut.models;

public class ProductModel {

    private int id;
    private String name;
    private double price;
    private String description;
    private int sellerId;
    private String photo;
    private int conditionOfProduct;
    private boolean isNegotiable;

    public boolean isNegotiable() {
        return isNegotiable;
    }

    public void setNegotiable(boolean negotiable) {
        isNegotiable = negotiable;
    }

    // Constructors
    public ProductModel() {
    }

    public ProductModel(int id, String name, double price, String description, int sellerId, String photo, int conditionOfProduct, boolean isNegotiable) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.sellerId = sellerId;
        this.photo = photo;
        this.conditionOfProduct = conditionOfProduct;
        this.isNegotiable = isNegotiable;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSellerId() {
        return sellerId;
    }

    public void setSellerId(int sellerId) {
        this.sellerId = sellerId;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public int getConditionOfProduct() {
        return conditionOfProduct;
    }

    public void setConditionOfProduct(int conditionOfProduct) {
        this.conditionOfProduct = conditionOfProduct;
    }
}


/* package com.burakefeogut.models;

public class ProductModel {

    int id;
    String name;
    double price;
    String description;
    int sellerId;
    String photo;
    int conditionOfProduct;
    boolean isNegotiable;

    public ProductModel() {
    }

    public ProductModel(int id, String name, double price, String description, int sellerId, String photo, int conditionOfProduct, boolean isNegotiable) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.sellerId = sellerId;
        this.photo = photo;
        this.conditionOfProduct = conditionOfProduct;
        this.isNegotiable=isNegotiable;
    }
   
    public boolean getIsNegotiable() {
        return isNegotiable;
    }

    public void setIsNegotiable(Boolean isNegotiable) {
        this.isNegotiable = isNegotiable;
    } 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSellerId() {
        return sellerId;
    }

    public void setSellerId(int sellerId) {
        this.sellerId = sellerId;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public int getConditionOfProduct() {
        return conditionOfProduct;
    }

    public void setConditionOfProduct(int conditionOfProduct) {
        this.conditionOfProduct = conditionOfProduct;
    }


} */