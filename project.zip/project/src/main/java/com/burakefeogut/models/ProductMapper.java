package com.burakefeogut.models;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductMapper implements RowMapper <ProductModel>{
    @Override
    public ProductModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        ProductModel product = new ProductModel(rs.getInt("id"), rs.getString("name"),rs.getDouble("price"),rs.getString("description"),rs.getInt("seller_id"),rs.getString("photo"),rs.getInt("conditionOfProduct"), rs.getBoolean("isNegotiable"));

        return product;
    }
}
