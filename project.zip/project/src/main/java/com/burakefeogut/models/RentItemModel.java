package com.burakefeogut.models;

public class RentItemModel {
    int id;
    String name;
    double price;
    String description;
    int sellerId;
    String photo;
    int conditionOfProduct;
    boolean isNegotiable;
    int rentDay;

    public RentItemModel(int id, String name, double price, String description, int sellerId, String photo, int conditionOfProduct, boolean isNegotiable, int rentDay) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.sellerId = sellerId;
        this.photo = photo;
        this.conditionOfProduct = conditionOfProduct;
        this.isNegotiable=isNegotiable; 
        this.rentDay = rentDay;
    }

    public int getRentDay() {
        return rentDay;
    }

    public void setRentDay(int rentDay) {
        this.rentDay = rentDay;
    }


    public boolean getIsNegotiable() {
        return isNegotiable;
    }

    public void setIsNegotiable(Boolean isNegotiable) {
        this.isNegotiable = isNegotiable;
    } 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSellerId() {
        return sellerId;
    }

    public void setSellerId(int sellerId) {
        this.sellerId = sellerId;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public int getConditionOfProduct() {
        return conditionOfProduct;
    }

    public void setConditionOfProduct(int conditionOfProduct) {
        this.conditionOfProduct = conditionOfProduct;
    }



}