package com.burakefeogut.models;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DonationsMapper implements RowMapper <DonationModel>{

    @Override
    public DonationModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        DonationModel donation = new DonationModel(rs.getInt("ID"), rs.getInt("clubid"), rs.getString("DESCRIPTION"), rs.getString("CLUBNAME"));
        return donation;
    }
    
}/* package com.burakefeogut.models;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DonationsMapper implements RowMapper <DonationModel>{

    @Override
    public DonationModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        DonationModel donation = new DonationModel(rs.getInt("ID"), rs.getString("DESCRIPTION"), rs.getString("CLUBNAME"));
        return donation;
    }
    
}
 */