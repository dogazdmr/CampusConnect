package com.burakefeogut.models;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ItemsMapper implements RowMapper <ItemModel>{

    @Override
    public ItemModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        ItemModel item = new ItemModel(rs.getInt("itemId"), rs.getString("itemName"), rs.getString("itemPlace"), rs.getString("itemDescription"), rs.getBoolean("lostOrFound"));
        return item;
    }
}