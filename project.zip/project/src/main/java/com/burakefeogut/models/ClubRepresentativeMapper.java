package com.burakefeogut.models;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ClubRepresentativeMapper implements RowMapper <ClubRepresentativeModel>{
    
    @Override
    public ClubRepresentativeModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        ClubRepresentativeModel club = new ClubRepresentativeModel(rs.getInt("user_id"), rs.getInt("club_id"), rs.getString("username"), rs.getString("password"));
        return club;
    }
}