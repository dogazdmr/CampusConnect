package com.burakefeogut.models;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.springframework.jdbc.core.RowMapper;
import com.burakefeogut.models.MessageModel;

public class MessagesMapper implements RowMapper<MessageModel> {
    @Override
    public MessageModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        int id = rs.getInt("id");
        String messageText = rs.getString("message_text");
        Timestamp timestamp = rs.getTimestamp("created_datetime");
        LocalDateTime createdDateTime = (timestamp != null) ? timestamp.toLocalDateTime() : null;
        String messageFrom = rs.getString("message_from");
        String messageTo = rs.getString("message_to");

        return new MessageModel(id, messageText, createdDateTime, messageFrom, messageTo);
    }
}