package com.burakefeogut.models;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RentItemMapper implements RowMapper<RentItemModel> {

    @Override
    public RentItemModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        RentItemModel rentItem = new RentItemModel(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getDouble("price"),
            rs.getString("description"),
            rs.getInt("sellerId"),
            rs.getString("photo"),
            rs.getInt("conditionOfProduct"),
            rs.getBoolean("isNegotiable"),
            rs.getInt("rentDay")
        );
        return rentItem;
    }
}